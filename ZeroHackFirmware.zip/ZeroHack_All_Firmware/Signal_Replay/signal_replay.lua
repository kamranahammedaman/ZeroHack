subghz.read("garage.sig")
subghz.send("garage.sig")