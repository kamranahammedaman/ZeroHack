-- Flipper Zero NFC Ping (Lua Script)
nfc.tag.write("PING TEST")