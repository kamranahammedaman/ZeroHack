Download from: https://github.com/spacehuhn/esp8266_deauther
Flash the .bin firmware on ESP8266 using NodeMCU or ESP Flasher.