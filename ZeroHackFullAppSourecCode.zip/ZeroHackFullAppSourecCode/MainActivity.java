package com.zerohack.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView statusDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusDisplay = findViewById(R.id.statusDisplay);

        initButton(R.id.irBlastBtn, "IR Blast Triggered");
        initButton(R.id.rfSendBtn, "RF Signal Sent");
        initButton(R.id.nfcPingBtn, "NFC Ping Sent");
        initButton(R.id.wifiJamBtn, "WiFi Jam Activated");
        initButton(R.id.gpioControlBtn, "GPIO Signal Sent");
        initButton(R.id.badUsbBtn, "BadUSB Payload Executed");
        initButton(R.id.rfidEmulateBtn, "RFID Emulated");
        initButton(R.id.ibuttonEmulateBtn, "iButton Emulated");
        initButton(R.id.subghzScanBtn, "SubGHz Scan Started");
        initButton(R.id.signalReplayBtn, "Signal Replay Sent");
        initButton(R.id.bluetoothHackBtn, "Bluetooth Attack Started");
        initButton(R.id.wifiDeauthBtn, "WiFi Deauth Running");
        initButton(R.id.logicAnalyzerBtn, "Logic Analyzer Running");
        initButton(R.id.uartHackBtn, "UART Hack Initiated");

        initButton(R.id.usbConnectBtn, "OTG Connected");
        initButton(R.id.bluetoothConnectBtn, "Bluetooth Connected");
        initButton(R.id.wifiConnectBtn, "WiFi Connected");
    }

    private void initButton(int id, String message) {
        Button btn = findViewById(id);
        btn.setOnClickListener(v -> statusDisplay.setText(message));
    }
}